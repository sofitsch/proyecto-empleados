from django.urls import path
from . import views

app_name = "empleado_app"
